<img style='min-width: 70%!important;
			max-height: 630px;
			margin-right: auto!important;
			margin-left: auto!important;
			display: flex;' 
	 alt='404 - Page Not Found' 
	 src='{{asset('img/not_found.jpg')}}' />
