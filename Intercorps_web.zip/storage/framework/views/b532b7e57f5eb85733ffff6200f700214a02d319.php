<img style='min-width: 70%!important;
			max-height: 630px;
			margin-right: auto!important;
			margin-left: auto!important;
			display: flex;' 
	 alt='404 - Page Not Found' 
	 src='<?php echo e(asset('img/not_found.jpg')); ?>' />
<?php /**PATH C:\xampp\htdocs\Intercorps_web\resources\views/not_found.blade.php ENDPATH**/ ?>