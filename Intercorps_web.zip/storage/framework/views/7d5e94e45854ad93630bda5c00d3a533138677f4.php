
<?php $__env->startSection('title_page', 'Adicionar url'); ?>
<?php $__env->startPush('css'); ?>
    <link href="//cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container col-8 mx-auto">
        <div class="row my-3">
            <a href="<?php echo e(route('home')); ?>" title="Adicionar uma nova url" class='btn btn-success d-block ml-auto mr-3 p-2'>
                <i class="<?php echo e(config('app.material')); ?>">arrow_back</i> Visualizar url
            </a>
        </div>
        
        <form action="<?php echo e(route('url.update', encrypt($url->id))); ?>" method="POST" id="form_atualizar_url" class='p-2 border boder-secondary'>
            
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <legend class="text-center text-muted">Atualizar url</legend>
            <div class="form-group">                
                <input type="url" name='url' id='url' class="form-control" value="<?php echo e(old('url') ? old('url') : $url->url); ?>" required>
                <p class="text-danger font-weight-bold"><?php echo e($errors->has('url') ? $errors->first('url') : ''); ?></p>
            </div>
            <div class="row">
                <button type='submit' class="btn btn-info rounded d-block ml-auto mr-3 text-white <?php echo e(config('app.bold')); ?>">
                    <i class="<?php echo e(config('app.material')); ?>">autorenew</i> Atualizar url
                </button>
            </div>
        </form>        
    </div>

    <?php $__env->startPush('js'); ?>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Intercorps_web\resources\views/url/atualizar.blade.php ENDPATH**/ ?>