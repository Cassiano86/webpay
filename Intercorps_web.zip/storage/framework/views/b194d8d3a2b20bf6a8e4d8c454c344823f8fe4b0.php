<?php $__env->startSection('title_page', 'Página inicial'); ?>

<?php $__env->startSection('content'); ?>
    <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">

        

        <div class="container">
            <h2 class='text-center text-success'>Mantenha vigilância constante em seus sites com a <span class="<?php echo e(config('app.bold')); ?>">Intercorp web</span></h2>

            <div class="row mt-5">
                <div class="col-lg-4 col-sm-12">
                    <i class="<?php echo e(config('app.material')); ?> md-100 d-flex justify-content-center my-3 text-info">person_pin</i>
                    <h5 class='text-center font-weight-bold text-secondary'>1º Passo - Efetue seu login ou cadastre-se</h5> 
                </div>
                <div class="col-lg-4 col-sm-12">
                    <i class="<?php echo e(config('app.material')); ?> md-100 d-flex justify-content-center my-3 text-info">http</i>
                    <h5 class='text-center font-weight-bold text-secondary'>2º Passo - Cadastre os  sites que deseja monitorar</h5>
                </div>
                <div class="col-lg-4 col-sm-12">
                    <i class="<?php echo e(config('app.material')); ?> md-100 d-flex justify-content-center my-3 text-info">trending_up</i>
                    <h5 class='text-center font-weight-bold text-secondary'>3º Passo - Acompanhe a cada minuto o monitoramento dos seus sites</h5>                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Intercorps_web\resources\views/welcome.blade.php ENDPATH**/ ?>