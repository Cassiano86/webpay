<?php $__env->startSection('title_page', 'Painel administrativo'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container px-0">
        <div class="row mt-3 mb-1">
            <span id='carregamento' class="text-dark <?php echo e(config('app.bold')); ?> mt-auto d-none">
                Atualizando <img class='ml-2' src="<?php echo e(asset('img/loading.gif')); ?>" alt="loading" width='30' height='30' />
            </span>
            <a href="<?php echo e(route('url.create')); ?>" title="Adicionar uma nova url" class='btn btn-primary d-block ml-auto mr-4 p-2'>
                <i class="<?php echo e(config('app.material')); ?>">add</i> Adicionar url
            </a>
        </div>
        <div class="row table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">URL</th>
                        <th scope="col">Status</th>
                        <th scope="col" colspan='3'>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr id="linha_<?php echo e($url->id); ?>">
                            <td id="link_<?php echo e($url->id); ?>">                                
                                <?php if(($url->status >= 200 &&  $url->status <= 226)): ?>
                                    <a href="<?php echo e($url->url); ?>" title='Acessar' target="_blank"><?php echo e($url->url); ?></a> <span class="text-danger d-none <?php echo e(config('app.bold')); ?>">- Desabilitado</span>
                                <?php else: ?>
                                    <a href="<?php echo e($url->url); ?>" class='desabilitado' title='Acessar' target="_blank"><?php echo e($url->url); ?></a> <span class="text-danger <?php echo e(config('app.bold')); ?>">- Desabilitado</span>
                                <?php endif; ?>                                
                            </td>
                            <td id="url_<?php echo e($url->id); ?>">
                                <?php if($url->status == null): ?>
                                    <span class="text-secondary <?php echo e(config('app.bold')); ?>">
                                        <i class="<?php echo e(config('app.material')); ?>">timer</i> Aguardando
                                    </span>
                                <?php elseif($url->status >= 200 &&  $url->status <= 226): ?>
                                    <span class="text-success <?php echo e(config('app.bold')); ?>">
                                        <i class="<?php echo e(config('app.material')); ?>">check</i> <?php echo e($url->status); ?>

                                    </span>
                                <?php elseif($url->status >= 400 &&  $url->status <= 451): ?>
                                    <span class="text-danger <?php echo e(config('app.bold')); ?>">
                                        <i class="<?php echo e(config('app.material')); ?>">error</i> <?php echo e($url->status); ?>

                                    </span>
                                <?php elseif($url->status >= 500 &&  $url->status <= 511): ?>
                                    <span class="text-warning <?php echo e(config('app.bold')); ?>">
                                        <i class="<?php echo e(config('app.material')); ?>">warning</i> <?php echo e($url->status); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-black-50 <?php echo e(config('app.bold')); ?>">
                                        <i class="<?php echo e(config('app.material')); ?>">visibility_off</i> Sem resposta
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="row mx-auto">
                                    <div class="col-lg-6">
                                        <a href="<?php echo e(route('url.edit', encrypt($url->id))); ?>" class="btn btn-info rounded-pill <?php echo e(config('app.bold')); ?> text-white" data-toggle="tooltip" data-placement="top" title="Atualizar url">
                                            <i class="<?php echo e(config('app.material')); ?>">autorenew</i>
                                        </a>
                                    </div>
                                    <div class="col-lg-6">
                                        <button class="btn btn-danger rounded-pill <?php echo e(config('app.bold')); ?>" data-href="<?php echo e(route('url.destroy', encrypt($url->id))); ?>" data-toggle="tooltip" data-placement="top" title="Deletar url">
                                            <i class="<?php echo e(config('app.material')); ?>">delete_forever</i>
                                        </button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan='6'>
                                <h4 class="text-center text-info font-weight-bold">
                                    <i class="<?php echo e(config('app.material')); ?>">language</i> Nenhum site cadastrado até o momento
                                </h4>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($urls->onEachSide(5)->links()); ?>

        </div>
    </div>

    <?php echo $__env->make('url.modals.modal_deletar_url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('js/painel_administrativo.js')); ?>"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Intercorps_web\resources\views/painel_administrativo.blade.php ENDPATH**/ ?>